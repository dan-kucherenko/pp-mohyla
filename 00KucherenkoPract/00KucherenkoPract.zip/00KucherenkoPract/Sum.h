#pragma once

long polynomialSum(const int* ptr_x, const int* ptr_n);