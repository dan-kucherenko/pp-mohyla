//
//Developed by Kucherenko Daniil on 09/26/22
//

#pragma once
double logarithm(double x, const int base);
