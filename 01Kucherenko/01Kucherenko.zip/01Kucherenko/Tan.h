//
//Developed by Kucherenko Daniil on 09/27/22 
//

#pragma once
double tangent(double x, double eps);