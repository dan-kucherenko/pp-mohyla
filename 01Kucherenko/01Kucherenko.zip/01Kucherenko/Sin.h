//
//Developed by Kucherenko Daniil on 09/27/22 
//

#pragma once
double sinFunct(const double* ptr_x, const double* ptr_e);
