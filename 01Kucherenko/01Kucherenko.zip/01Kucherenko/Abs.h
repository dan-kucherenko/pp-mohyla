//
//Developed by Kucherenko Daniil on 09/27/22
//

#pragma once
template  <typename T>
inline T myAbs(T x) {
	return x < 0 ? x = -x : x = x;
}
