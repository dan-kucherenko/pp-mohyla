//
//Developed by Kucherenko Daniil on 09/26/22
//

#include "Log.h"

int lg(const double x) {
	return logarithm(x, 10);
}
